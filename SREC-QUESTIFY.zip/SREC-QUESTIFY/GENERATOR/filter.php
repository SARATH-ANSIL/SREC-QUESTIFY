
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Insert Data</title>
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="style1.css">
</head>
<body>
<?php
session_start();
?>
    
    <div class="container mt-5">
       
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card-shadow">
                     <?php 
    if (isset($_SESSION['message'])) :?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong><?=$_SESSION['message']?></strong> 
    <a href="#" class="close" data-dismiss="alert">
            &times;
    </a>
    </div>
    <?php
    unset($_SESSION['message']);
    endif;
    
    ?>
                    <div class="card-header">
                        <h4 style="color:white;font-size:18px;padding:10px;">CHOOSE THE CORRECT ANSWER</h4>
                    </div>
                    <div class="card-body">

                        <form action="insert.php" method="REQUEST">

                            <div class="mb-3">
                                <input type="text" name="co" placeholder="Enter the Course Outcome" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                
                                <input type="text" name="cl" placeholder="Enter the Cognitive level" class="form-control" required>
                            </div>
                            <div class="mb-3">
                               
                                <input type="text" name="module" placeholder="Enter the Module" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <input type="text" name="question" placeholder="Enter the Question" class="form-control" required>
                            </div>
                          
                            <div class="mb-3">
                                <hr/>
                                <div class="bt">
                                <button style="padding-right:25px;padding-left:25px;" type="submit" name="insert_buttton" class="btn btn-primary">Insert</button>
</div>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
