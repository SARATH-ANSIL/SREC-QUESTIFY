<?php
$servername = "localhost";
$username = "root";
$password = "";
$conn = new mysqli($servername,
		$username, $password,'choose');
$conn1 = new mysqli($servername,
$username, $password,'fill');
$conn2 = new mysqli($servername,
$username, $password,'twom');
$conn3 = new mysqli($servername,
$username, $password,'tenm');
if ($conn->connect_error) {
die("Connection failed: "
	. $conn->connect_error);
}
session_start();
    $id =  mysqli_real_escape_string($conn,$_GET['id']);
    $sql = "DELETE FROM fill WHERE Question_id=$id";
    $query_run = mysqli_query($conn1,$sql);
    if($query_run)
    {
        $_SESSION['message'] = "Deleted";
        header("Location:in2.php");
        exit(0);
    }
?>