<?php
session_start();
require 'f.php';
    $id =  mysqli_real_escape_string($conn,$_GET['id']);
    $sql = "DELETE FROM choose WHERE Question_id=$id";
    $query_run = mysqli_query($conn,$sql);
    if($query_run)
    {
        $_SESSION['message'] = "Deleted";
        header("Location:in.php");
        exit(0);
    }
?>