<?php
session_start();
require 'f.php';
if(isset($_POST['edit'])){
    $q_id = mysqli_real_escape_string($conn,$_POST['q_id']); 
    $question = mysqli_real_escape_string($conn,$_POST['Question']);
    $co_level = mysqli_real_escape_string($conn,$_POST['CO']);
    $mark = mysqli_real_escape_string($conn,$_POST['MARK']);
    $u_level = mysqli_real_escape_string($conn,$_POST['Understanding']);
    $query = "UPDATE choose SET co='$co_level',module ='$mark',question='$question',cl='$u_level' where Question_id='$q_id'";
    $query_run = mysqli_query($conn,$query);
    if($query_run)
    {
        $_SESSION['message'] = "Updated";
        header("Location:in.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = " nOT updated ";
        header("Location:in.php");
        exit(0);
    }

}
elseif(isset($_POST['edit1'])){
    $q_id = mysqli_real_escape_string($conn1,$_POST['q_id']); 
    $question = mysqli_real_escape_string($conn1,$_POST['Question']);
    $co_level = mysqli_real_escape_string($conn1,$_POST['CO']);
    $mark = mysqli_real_escape_string($conn1,$_POST['MARK']);
    $u_level = mysqli_real_escape_string($conn1,$_POST['Understanding']);
    $query = "UPDATE fill SET co='$co_level',module ='$mark',question='$question',cl='$u_level' where Question_id='$q_id'";
    $query_run = mysqli_query($conn1,$query);
    if($query_run)
    {
        $_SESSION['message'] = "Updated";
        header("Location:in2.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = " nOT updated ";
        header("Location:in2.php");
        exit(0);
    }

}
elseif(isset($_POST['edit2'])){
    $q_id = mysqli_real_escape_string($conn2,$_POST['q_id']); 
    $question = mysqli_real_escape_string($conn2,$_POST['Question']);
    $co_level = mysqli_real_escape_string($conn2,$_POST['CO']);
    $mark = mysqli_real_escape_string($conn2,$_POST['MARK']);
    $u_level = mysqli_real_escape_string($conn2,$_POST['Understanding']);
    $query = "UPDATE twom SET co='$co_level',module ='$mark',question='$question',cl='$u_level' where Question_id='$q_id'";
    $query_run = mysqli_query($conn2,$query);
    if($query_run)
    {
        $_SESSION['message'] = "Updated";
        header("Location:in3.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = " nOT updated ";
        header("Location:in3.php");
        exit(0);
    }

}
elseif(isset($_POST['edit3'])){
    $q_id = mysqli_real_escape_string($conn3,$_POST['q_id']); 
    $question = mysqli_real_escape_string($conn3,$_POST['Question']);
    $co_level = mysqli_real_escape_string($conn3,$_POST['CO']);
    $mark = mysqli_real_escape_string($conn3,$_POST['MARK']);
    $u_level = mysqli_real_escape_string($conn3,$_POST['Understanding']);
    $query = "UPDATE tenm SET co='$co_level',module ='$mark',question='$question',cl='$u_level' where Question_id='$q_id'";
    $query_run = mysqli_query($conn3,$query);
    if($query_run)
    {
        $_SESSION['message'] = "Updated";
        header("Location:in4.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = " nOT updated ";
        header("Location:in4.php");
        exit(0);
    }

}
else{
    $id =  mysqli_real_escape_string($conn,$_GET['id']);
    $sql = "DELETE FROM choose WHERE Question_id=$id";
    $query_run = mysqli_query($conn,$sql);
    if($query_run)
    {
        $_SESSION['message'] = "Deleted";
        header("Location:in.php");
        exit(0);
    }
}