<?php
if (isset($_SESSION['message'])) :
?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
  <strong><?=$_SESSION['message']?></strong> 
  <a href="#" class="close" data-dismiss="alert">
            &times;
         </a>
</div>
<?php 
    unset($_SESSION['message']);
endif;
?> 