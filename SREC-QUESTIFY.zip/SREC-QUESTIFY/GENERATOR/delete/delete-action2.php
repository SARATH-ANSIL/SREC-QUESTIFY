<?php
session_start();
require 'f.php';
    $id =  mysqli_real_escape_string($conn,$_GET['id']);
    $sql = "DELETE FROM fill WHERE Question_id=$id";
    $query_run = mysqli_query($conn1,$sql);
    if($query_run)
    {
        $_SESSION['message'] = "Deleted";
        header("Location:in2.php");
        exit(0);
    }
?>