<?php 
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$conn = new mysqli($servername,
		$username, $password,'choose');
$conn1 = new mysqli($servername,
$username, $password,'fill');
$conn2 = new mysqli($servername,
$username, $password,'twom');
$conn3 = new mysqli($servername,
$username, $password,'tenm');
if ($conn->connect_error) {
die("Connection failed: "
	. $conn->connect_error);
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>Bootstrap demo</title>
  </head>
  <body>
  <style>
    
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@350&display=swap');
        * {
       font-family: "Poppins", sans-serif;
       margin: 0;
       padding: 0;
       box-sizing: border-box;
       outline: none;
       border: none;
       text-decoration: none;
}
        body{
            background-image: url('./srec.jpg');
            background-size: cover;
            background-repeat: no-repeat;
        }
        .card{
            background: rgba(0,0,0,0.5);
            position: relative;
            top:200px;
            color:white;
            font-size:15px;
            width:800px;
            height:430px;
           
            margin-left: 230px;
        }
        .card .card-body .satheesh
        {
            margin-left: 280px;
        }

    </style>
<div class="container">
   
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                <h4 style="color:white; text-align:center;font-size:20px;">UPDATE QUESTION
                        <a href="in3.php" class="btn btn-primary float-end">Back</a>
                    </h4>
                     
                </div>
                <div class="card-body">
                    <?php
                    if(isset($_GET['id']))
                    {
                        $qp_id = mysqli_real_escape_string($conn2,$_GET['id']);
                        $query = "select * from twom where Question_id ='$qp_id' ";
                        $query_run=mysqli_query($conn2,$query);
                        if(mysqli_num_rows($query_run)>0)
                        {
                            $row = mysqli_fetch_array($query_run);
                            ?>

                    <form action="edit-action.php" method="POST">
                        <input type="hidden" name="q_id" value=<?=$qp_id ?>>
                        <div class="mb-3">
                            <label>CO LEVEL</label>
                            <input type="text" name="CO" value ="<?=$row['co']?>" class="form-control" required>
                                
                            
                        </div>
                        <div class="mb-3">
                            <label>MODULE</label>
                            <input type="text" name="MARK" value ="<?=$row['module']?>" class="form-control" required>
                        </div>                      
                        <div class="mb-3">
                            <label>QUESTION</label>
                            <input type="text" name="Question" value ="<?=$row['question']?>" class="form-control" required>
                        </div>                        
                        <div class="mb-3">
                            <label>COGNITIVE LEVEL</label>
                            <input type="text" name="Understanding" value ="<?=$row['cl']?>" class="form-control" required>
                        </div>
                        <div class="satheesh">
                        <div class="mb-3">
                            <button type="submit" name="edit2" class="btn btn-primary">UPDATE QUESTION</button>
                        </div>
                        </div>
                    </form>
                            <?php
                        }
                        else
                        { 
                            echo 'not found';
                        }
                    }

                    ?>

                </div>
            </div>
        </div>
    </div>
</div>        
</div>


  </body>
</html> 