<?php
$servername = "localhost";
$username = "root";
$password = "";
$conn = new mysqli($servername,
		$username, $password,'choose');
$conn1 = new mysqli($servername,
$username, $password,'fill');
$conn2 = new mysqli($servername,
$username, $password,'twom');
$conn3 = new mysqli($servername,
$username, $password,'tenm');
if ($conn->connect_error) {
die("Connection failed: "
	. $conn->connect_error);
}
session_start();
?>
<!DOCTYPE html>
<html lang="eng">
    <head>
        <meta charset ="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE-edge">
        <meta name ="viewport" content="width=device-width,initial-scale =1.0">
        <title>
            Update Question paper
        </title>

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    </head>
    <style>
         
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@350&display=swap');
        * {
       font-family: "Poppins", sans-serif;
       margin: 0;
       padding: 0;
       box-sizing: border-box;
       outline: none;
       border: none;
       text-decoration: none;
}
        
        body{
            background-image: url('./srec.jpg');
            background-size: cover;
            background-repeat: no-repeat;
           
        }
        .container{
            width: inherit;
            background-color: rgba(256,256,256,0.2);
            position: relative;
            top:150px;
           
        }
        .row{
            overflow-y: scroll;
            height: fit-content;
            max-height: 400px;
        }

        .table{
            background-color: rgba(256,256,256,0.5);
            border-collapse: separate;
            
        }
        table thead
        {
            position: sticky;
            top:0px;
            color: aliceblue;
            background:black;

        }
        h1{
            text-align: center;
            font-size: 20px;
            padding-top:10px;
        }
        .alert{
            background-color: rgba(0,0,0,0.5);
            color: white;
            border-color:rgba(0,0,0,0.5);
            

        }
        a{
            text-decoration: none;
            color: black;
            background: rgba(256,256,256,0.5);
            padding-left: 6px;
            padding-right: 6px;
            padding-bottom:5px;
            border-radius:15px;

        }

    </style>

    <body>
    
        <div class="container my-5 ">
        <?php include('message.php'); ?>
            <h1 >TEN MARKS</h1>
            <a class="btn btn-primary" href="in3.php" role="button">BACK</a>
            <br>                                                     
            <div class="row">
            <table class="table" >
                <thead >
                    <tr>
                        
                    <div class="sand"><th>ID</th></div>
                        <th>CO LEVEL</style></th>
                        <th>Congnitive level</th>
                        <th>Question</th>
                        <th>Module</th>
                        <th>Action</th>

                    </tr>
                </thead>
                <tbody style="border:1px;">
                    <?php
                    $sql="select * from tenm";
                    $res=$conn3->query($sql);
                    if (!$res) {
                        die("Invalid query ". $conn3->error);
                    }
                
                    while($row=$res->fetch_assoc()){
                        ?>
                        <tr >
                            <td><?= $row['Question_id']; ?></td>
                            <td><?= $row['co']; ?></td>
                            <td><?= $row['cl']; ?></td>
                            <td><?= $row['question']; ?></td>
                            <td><?= $row['module']; ?></td>
                            <td>
                            <a href="edit3.php?id=<?=$row['Question_id'];?>" class='btn btn-primary btn-sm' >EDIT</a>
                            <a href="delete-action4.php?id=<?=$row['Question_id'];?>" class='btn btn-danger btn-sm' >DELETE</a>
                            </td>
                    
                        </tr> 
                        <?php
                    } 

                    ?>
                </tbody>
            </table>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
<html>