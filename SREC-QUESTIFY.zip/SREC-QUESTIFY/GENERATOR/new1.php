<?php
if(isset($_GET['sub']))
{
    $sub=$_GET['sub'];
    $date=$_GET['date'];
}
$db1 = mysqli_connect("localhost", "root", "", "choose");
$db2 = mysqli_connect("localhost", "root", "", "fill");
$db3 = mysqli_connect("localhost", "root", "", "twom");
$db4 = mysqli_connect("localhost", "root", "", "tenm");
if(isset($_GET['module']))
{
$module=$_GET['module'];
if(isset($_GET['module1']))
{
$module1=$_GET['module1'];
$result1 = mysqli_query($db1, "SELECT * FROM choose WHERE  module BETWEEN '$module' AND '$module1' ORDER BY RAND() LIMIT 7 ");
$data1 = mysqli_fetch_all($result1, MYSQLI_ASSOC);

if(isset($_GET['module']))
{
$module=$_GET['module'];
if(isset($_GET['module1']))
{
$module1=$_GET['module1'];
$result2 = mysqli_query($db2, "SELECT * FROM fill WHERE  module BETWEEN '$module' AND '$module1' ORDER BY RAND() LIMIT 3");
$data2 = mysqli_fetch_all($result2, MYSQLI_ASSOC);
if(isset($_GET['module']))
{
$module=$_GET['module'];
if(isset($_GET['module1']))
{
$module1=$_GET['module1'];
$result3 = mysqli_query($db3, "SELECT * FROM twom WHERE  module BETWEEN '$module' AND '$module1' ORDER BY RAND() LIMIT 5 ");
$data3 = mysqli_fetch_all($result3, MYSQLI_ASSOC);
if(isset($_GET['module']))
{
$module=$_GET['module'];
if(isset($_GET['module1']))
{
$module1=$_GET['module1'];
$result4 = mysqli_query($db4, "SELECT * FROM tenm WHERE  module BETWEEN '$module' AND '$module1' ORDER BY RAND() LIMIT 4 ");
$data4 = mysqli_fetch_all($result4, MYSQLI_ASSOC);
require('fpdf185/fpdf.php');
$pdf = new FPDF();
$pdf->AddPage();

/*$width=$pdf->GetPageWidth();
$height=$pdf->GetPageHeight();
$gap=10; 
$pdf->Line($gap, $gap,$width-$gap,$gap); 
$pdf->Line($gap, $height-$gap,$width-$gap,$height-$gap); 
$pdf->Line($gap, $gap,$gap,$height-$gap); 
$pdf->Line($width-$gap, $gap,$width-$gap,$height-$gap);*/
$pdf->SetFont('Times','B',10);
$pdf->Image("title.jpg",15,11,180,40);
$pdf->Ln(50);
$u_count=0;
$an_count=0;
$ap_count=0;
$r_count=0;
$e_count=0;
$c_count=0;
foreach($data1 as $r){


    if($r['cl'] == 'U'){
     ++$u_count;
    }
    elseif($r['cl'] == 'AP'){
        ++$ap_count;
    }
    elseif($r['cl'] == 'R'){
        ++$r_count;
    }
    elseif($r['cl'] == 'An'){
        ++$an_count;
    }
    elseif($r['cl'] == 'E'){
        ++$e_count;
    }
    elseif($r['cl'] == 'C'){
        ++$c_count;
    }
}
$u_count2=0;
$an_count2=0;
$ap_count2=0;
$r_count2=0;
$e_count2=0;
$c_count2=0;
foreach($data2 as $r){


    if($r['cl'] == 'U'){
     ++$u_count2;
    }
    elseif($r['cl'] == 'AP'){
        ++$ap_count2;
    }
    elseif($r['cl'] == 'R'){
        ++$r_count2;
    }
    elseif($r['cl'] == 'An'){
        ++$an_count2;
    }
    elseif($r['cl'] == 'E'){
        ++$e_count2;
    }
    elseif($r['cl'] == 'C'){
        ++$c_count2;
    }
}
$u_count3=0;
$an_count3=0;
$ap_count3=0;
$r_count3=0;
$e_count3=0;
$c_count3=0;
foreach($data3 as $r){


    if($r['cl'] == 'U'){
     ++$u_count3;
    }
    elseif($r['cl'] == 'AP'){
        ++$ap_count3;
    }
    elseif($r['cl'] == 'R'){
        ++$r_count3;
    }
    elseif($r['cl'] == 'An'){
        ++$an_count3;
    }
    elseif($r['cl'] == 'E'){
        ++$e_count3;
    }
    elseif($r['cl'] == 'C'){
        ++$c_count3;
    }
}
$u_count4=0;
$an_count4=0;
$ap_count4=0;
$r_count4=0;
$e_count4=0;
$c_count4=0;
foreach($data4 as $r){


    if($r['cl'] == 'U'){
     ++$u_count4;
    }
    elseif($r['cl'] == 'AP'){
        ++$ap_count4;
    }
    elseif($r['cl'] == 'R'){
        ++$r_count4;
    }
    elseif($r['cl'] == 'An'){
        ++$an_count4;
    }
    elseif($r['cl'] == 'E'){
        ++$e_count4;
    }
    elseif($r['cl'] == 'C'){
        ++$c_count4;
    }
}
$pdf->Cell(190,10,"Internal Test - ".$sub,1,1,'C');
$pdf->Cell(47.5,7,'Date ',1,0,'C');
$pdf->Cell(47.5,7,$date,1,0,'C');
$pdf->Cell(47.5,7,'Department',1,0,'C');
$pdf->Cell(47.5,7,'CSE',1,1,'C');
$pdf->Cell(47.5,7,'Semester',1,0,'C');
$pdf->Cell(47.5,7,'IV',1,0,'C');
$pdf->Cell(47.5,7,'Class/Section',1,0,'C');
$pdf->Cell(47.5,7,'II B.E CSE & II M.Tech CSE',1,1,'C');
$pdf->Cell(47.5,7,'Duration',1,0,'C');
$pdf->Cell(47.5,7,'2:00 hours',1,0,'C');
$pdf->Cell(47.5,7,'Maximum Marks',1,0,'C');
$pdf->Cell(47.5,7,'50',1,1,'C');
$pdf->Cell(190,10,'Course Code &Title: 20CS205 & Algorithms and Complexity I',1,1,'C');
$pdf->Ln(10);
$pdf->Cell(170,10,'PART - A (Answer All Questions) (10*1 =10 Marks)',0,0,'C');
$pdf->Cell(5,10,'Cognitive Level/CO',0,0,'C');
$pdf->Ln();
$k=1;
foreach ($data1 as $row) {
    
    $pdf->Cell(10,10," ");
    $pdf->Cell(10,10,$k++);
    $pdf->MultiCell(120,8,$row['question']);
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->SetXY($x + 160, $y-5);
    $pdf->Cell(0,0,$row['co']);
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->SetXY($x-20, $y-5);
    $pdf->Cell(0,10,$row['cl']);
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->SetXY($x-10, $y);
$pdf->Cell(0,10,$row['module']);
$pdf->Ln();

}
$i=8;
foreach ($data2 as $row) {
    $pdf->Cell(10,10," ");
    $pdf->Cell(10,10,$i++);
    $pdf->MultiCell(120,8,$row['question']);
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->SetXY($x + 160, $y-5);
    $pdf->Cell(0,0,$row['co']);
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->SetXY($x-20, $y-5);
    $pdf->Cell(0,10,$row['cl']);
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->SetXY($x-10, $y);
$pdf->Cell(0,10,$row['module']);
$pdf->Ln();

}

$pdf->Ln();  
$pdf->Cell(170,10,'PART - B (Answer All Questions) (5*2 =10 Marks)',0,0,'C');
$pdf->Cell(5,10,'Cognitive Level/CO',0,0,'C');
$pdf->Ln();  
$j=11;
foreach ($data3 as $row) {
    $pdf->Cell(10,10," ");
    $pdf->Cell(10,10,$j++);
    $pdf->MultiCell(120,8,$row['question']);
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->SetXY($x + 160, $y-5);
    $pdf->Cell(0,0,$row['co']);
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->SetXY($x-20, $y-5);
    $pdf->Cell(0,10,$row['cl']);
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->SetXY($x-10, $y);
$pdf->Cell(0,10,$row['module']);
$pdf->Ln();

}
$pdf->Ln();  
$pdf->Cell(170,10,'PART - C (Answer any 3 Questions) (3*10 =30 Marks)',0,0,'C');
$pdf->Cell(5,10,'Cognitive Level/CO',0,0,'C');
$pdf->Ln();  
$l=11;
foreach ($data4 as $row) {
    $pdf->Cell(10,10," ");
    $pdf->Cell(10,10,$l++);
    $pdf->MultiCell(120,8,$row['question']);
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->SetXY($x + 160, $y-5);
    $pdf->Cell(0,0,$row['co']);
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->SetXY($x-20, $y-5);
    $pdf->Cell(0,10,$row['cl']);
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->SetXY($x-10, $y);
$pdf->Cell(0,10,$row['module']);
$pdf->Ln();

}
$fr_count=$r_count+$r_count2+($r_count3*2)+($r_count4*10);
$fu_count=$u_count+$u_count2+($u_count3*2)+($u_count4*10);
$fap_count=$ap_count+$ap_count2+($an_count3*2)+($ap_count4*10);
$fan_count=$an_count+$an_count2+($an_count3*2)+($an_count4*10);
$fe_count=$e_count+$e_count2+($e_count3*2)+($e_count4*10);
$fc_count=$c_count+$c_count+($c_count3*2)+($c_count4*10);
$f=$fr_count+$fu_count+$fap_count+$fan_count+$fe_count+$fc_count;
$percent=$f*2;

#$pdf->Cell(47.5,7,($u_count2*2).' '.$ap_count2.' '.$r_count2,1,0,'C');
$pdf->Cell(47.5,7,'S.no',1,0,'C');
$pdf->Cell(47.5,7,'Cognitive Level addressed',1,0,'C');
$pdf->Cell(47.5,7,'Marks',1,0,'C');
$pdf->Cell(47.5,7,'Percentage',1,1,'C');
$pdf->SetFont('Times','',10);
$pdf->Cell(47.5,7,'1',1,0,'C');
$pdf->Cell(47.5,7,'Remember (R)',1,0,'C');
$pdf->Cell(47.5,7,$fr_count,1,0,'C');
$pdf->Cell(47.5,7,($fr_count*2),1,1,'C');
$pdf->Cell(47.5,7,'2',1,0,'C');
$pdf->Cell(47.5,7,'Understand (U)',1,0,'C');
$pdf->Cell(47.5,7,$fu_count,1,0,'C');
$pdf->Cell(47.5,7,($fu_count*2),1,1,'C');
$pdf->Cell(47.5,7,'3',1,0,'C');
$pdf->Cell(47.5,7,'Apply (Ap)',1,0,'C');
$pdf->Cell(47.5,7,$fap_count,1,0,'C');
$pdf->Cell(47.5,7,($fap_count*2),1,1,'C');
$pdf->Cell(47.5,7,'4',1,0,'C');
$pdf->Cell(47.5,7,'Analyze (An)',1,0,'C');
$pdf->Cell(47.5,7,$fan_count,1,0,'C');
$pdf->Cell(47.5,7,($fan_count*2),1,1,'C');
$pdf->Cell(47.5,7,'5',1,0,'C');
$pdf->Cell(47.5,7,'Evaluate (E)',1,0,'C');
$pdf->Cell(47.5,7,$fe_count,1,0,'C');
$pdf->Cell(47.5,7,($fe_count*2),1,1,'C');
$pdf->Cell(47.5,7,'6',1,0,'C');
$pdf->Cell(47.5,7,'Create (C)',1,0,'C');
$pdf->Cell(47.5,7,$fc_count,1,0,'C');
$pdf->Cell(47.5,7,($fc_count*2),1,1,'C');
$pdf->Cell(95,10,"Total",1,0,'C');
$pdf->Cell(47.5,10,$f,1,0,'C');
$pdf->Cell(47.5,10,$percent,1,1,'C');

$pdf->Output();
}}}}}}}}
?>
