


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>edit/delete</title>
   <link rel="stylesheet" href="style.css">

</head>
<style>

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap');
        * {
       font-family: "Poppins", sans-serif;
       margin: 0;
       padding: 0;
       box-sizing: border-box;
       outline: none;
       border: none;
       text-decoration: none;
}
</style>
<body>
   
<div class="container">

   <div class="content">
      <a href="filter.php" class="btn">Choose</a>
      <a href="filter2.php" class="btn">Fill up</a>
      <a href="filter3.php" class="btn">Two mark</a>
      <a href="filter4.php" class="btn">Ten mark</a>
   </div>

</div>

</body>
</html>