<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$conn = new mysqli($servername,
		$username, $password,'choose');
$conn1 = new mysqli($servername,
$username, $password,'fill');
$conn2 = new mysqli($servername,
$username, $password,'twom');
$conn3 = new mysqli($servername,
$username, $password,'tenm');
if ($conn->connect_error) {
die("Connection failed: "
	. $conn->connect_error);
}
    $id =  mysqli_real_escape_string($conn2,$_GET['id']);
    $sql = "DELETE FROM twom WHERE Question_id=$id";
    $query_run = mysqli_query($conn2,$sql);
    if($query_run)
    {
        $_SESSION['message'] = "Deleted";
        header("Location:in3.php");
        exit(0);
    }
?>