<?php
session_start();
?>
<!DOCTYPE html>
<html>

<head>
	<title>Insert Page</title>
</head>

<body>
		<?php

		$conn = mysqli_connect("localhost", "root", "", "fill");
		
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		// Taking all 5 values from the form data(input)
		$Question_id = $_REQUEST['Question_id'];
		$CO = $_REQUEST['co'];
		$Cognitive_level = $_REQUEST['cl'];
		$Module = $_REQUEST['module'];
		$Question = $_REQUEST['question'];
		
		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO fill VALUES (null,
			'$CO','$Cognitive_level','$Module','$Question')";
		
		if(mysqli_query($conn, $sql)){
	            $_SESSION['message'] = "Inserted";
                header("Location:filter.php");
                exit(0);
		
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		// Close connection
		mysqli_close($conn);
	?>

	
</body>

</html>