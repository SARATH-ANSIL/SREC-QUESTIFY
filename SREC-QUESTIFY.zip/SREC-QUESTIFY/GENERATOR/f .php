<?php
$servername = "localhost";
$username = "root";
$password = "";
$conn = new mysqli($servername,
		$username, $password,'choose');
$conn1 = new mysqli($servername,
$username, $password,'fill');
$conn2 = new mysqli($servername,
$username, $password,'twom');
$conn3 = new mysqli($servername,
$username, $password,'tenm');
if ($conn->connect_error) {
die("Connection failed: "
	. $conn->connect_error);
}
?>

