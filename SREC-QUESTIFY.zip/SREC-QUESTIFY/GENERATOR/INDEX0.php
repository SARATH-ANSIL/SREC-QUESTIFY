<!DOCTYPE html>
<html lang="en">
<head>
    <style>
         
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@350&display=swap');
        * {
       font-family: "Poppins", sans-serif;
       margin: 0;
       padding: 0;
       box-sizing: border-box;
       outline: none;
       border: none;
       text-decoration: none;
}
        body
        {
            background-image: url("srec.jpg");
            background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
        }
        .container .col-md-7
        {
            padding-top:200px;
            height:50px;
            width:700px;
            font-size: 15px;
            font-weight: 500;
            color: white;
        }
        .container .card-body
        {
            background-color: rgba(100, 100,100,0);
        }
        .container .col-md-4 
        {
           padding-top: 45px;
           padding-left: 1px;
           
           
        }
        .container .card
        {
            background-color:rgba(0, 0, 0, 0.5) ;
            padding-bottom: 20px;
        }
      

        .container .col-md-12 .form-control
        {
          border-radius: 50px;
        }
        .container .col-md-8 .form-control
        {
          border-radius: 50px;
          width:250px;
          margin-top: 20px;
        }
     a:link, a:visited {
  background-color:dodgerblue;
  color: white;
  margin-top: 10px;
  margin-left:270px;
  border-radius: 15px;
  padding: 8px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color:rgba(30, 144, 255,0.8);
  color: black;
}
    
        </style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">

                <div class="card mt-5">
                    <div class="card-header text-center">
                    <h4 style="color:white;font-size:20px;">FILL IN THE BLANKS</h4>
                    </div>
                    <div class="card-body">

                        <form action="INDEX2.php" method="GET" >
                           
                            <div class="row">
                                <div class="col-md-8">
<input type="text" name="module" value="<?php if(isset($_GET['module'])){echo $_GET['module'];} ?>" class="form-control" placeholder="Enter the module">
              <input type="text" name="module1" value="<?php if(isset($_GET['module1'])){echo $_GET['module1'];} ?>" class="form-control" placeholder="Enter the module">                  </div>
                                <div class="col-md-4">
                                    <button type="submit"  id='pdf' name="newpdf2" class="btn btn-primary" >Next</button>
                                    
                                </div>
                            </div>
                        </form>
                        <div class="sand">
                       
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <hr>
                               

                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

